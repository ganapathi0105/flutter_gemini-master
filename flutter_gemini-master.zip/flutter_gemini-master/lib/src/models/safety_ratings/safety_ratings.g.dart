// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'safety_ratings.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SafetyRatingsImpl _$$SafetyRatingsImplFromJson(Map<String, dynamic> json) =>
    _$SafetyRatingsImpl(
      category: json['category'] as String?,
      probability: json['probability'] as String?,
    );

Map<String, dynamic> _$$SafetyRatingsImplToJson(_$SafetyRatingsImpl instance) =>
    <String, dynamic>{
      'category': instance.category,
      'probability': instance.probability,
    };
